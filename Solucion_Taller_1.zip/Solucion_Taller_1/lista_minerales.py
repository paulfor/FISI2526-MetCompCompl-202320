from mineral import Mineral

f=open('./minerales.txt', "r", encoding="utf-8")
lineas=f.readlines()
f.close()

minerales=[]

for k in lineas[1:]:
    datos = k.strip().split("\t")
    nombre=datos[0]
    dureza=float(datos[1])
    fractura=(datos[2])
    color=datos[3]
    composicion=datos[4]
    lustre=datos[5]
    gravedad_especifica=float(datos[6])
    sistema_cristalino=[7]
    mineral_i=Mineral(nombre,dureza,fractura,color,composicion,lustre,gravedad_especifica,sistema_cristalino)
    minerales.append(mineral_i)

silicatos=0
total_densidades=0

for i in minerales:
    if i.es_silicato()==True:
        silicatos+=1
        print(i.nombre + " " + "es un Silicato:" + " " + i.composicion)
        
print("\n")
print("Hay un total de" + " " + str(silicatos) + " " + "Silicatos en la Lista" )
    
for i in minerales:
    total_densidades+=i.densidad_material()
densidad_promedio=round(float(total_densidades/len(minerales)),2)
print("La densidad promedio de los minerales es de:" + str(densidad_promedio) + "kg/m^3" )




    


    
    
