from expansiontermicamineral import ExpansionTermicaMineral
import matplotlib.pyplot as plt



archivo_grafito = 'graphite_mceligot_2016.csv'
archivo_olivino = 'olivine_angel_2017.csv'
grafito = ExpansionTermicaMineral('Grafito',1.5, False, "#5f6168", "C", "Metalico", 2.2, "Hexagonal", archivo_grafito)
olivino = ExpansionTermicaMineral('Olivino',6.5, True, "#9ab973", "(FeMg)2SiO4", "No Metalico", 3.9, "Ortorrombico", archivo_olivino)
alfas_grafito, error_global_grafito = grafito.coeficiente_expansion_termica()
alfas_olivino, error_global_olivino = olivino.coeficiente_expansion_termica()


#V vs T Grafito
plt.figure(figsize=(12, 5))
plt.subplot(1, 2, 1)
plt.plot(grafito.temperaturas, grafito.volumenes, marker='o', linestyle='-', color='b')
plt.xlabel('Temperatura (°C)')
plt.ylabel('Volumen (cm^3)')
plt.title('Volumen vs. Temperatura')
plt.tight_layout()
plt.savefig('grafica_grafito_V vs T.png')

#alfa vs T Grafito
plt.subplot(1, 2, 2)
plt.plot(grafito.temperaturas[1:-1], alfas_grafito, marker='o', linestyle='-', color='r')
plt.xlabel('Temperatura (°C)')
plt.ylabel('Coeficiente de Expansión Térmica (α)')
plt.title('α vs. Temperatura')
plt.tight_layout()
plt.savefig('grafica_grafito_alfa vs T.png')

#V vs T Olivino
plt.figure(figsize=(12, 5))
plt.subplot(1, 2, 1)
plt.plot(olivino.temperaturas, olivino.volumenes, marker='o', linestyle='-', color='b')
plt.xlabel('Temperatura (°C)')
plt.ylabel('Volumen (cm^3)')
plt.title('Volumen vs. Temperatura')
plt.tight_layout()
plt.savefig('grafica_olivino_V vs T.png')

#alfa vs T Olivino
plt.subplot(1, 2, 2)
plt.plot(olivino.temperaturas[1:-1], alfas_olivino, marker='o', linestyle='-', color='r')
plt.xlabel('Temperatura (°C)')
plt.ylabel('Coeficiente de Expansión Térmica (α)')
plt.title('α vs. Temperatura')
plt.tight_layout()
plt.savefig('grafica_olivino_alfa vs T.png')




