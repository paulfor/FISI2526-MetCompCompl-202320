import matplotlib.pyplot as plt
import pandas as pd
from mineral import Mineral


class ExpansionTermicaMineral (Mineral):
    def __init__(self, nombre:str,dureza:float,fractura:bool, color:str, composicion:str, lustre:str, gravedad_especifica:float, 
                 sistema_cristalino:str, archivo:str):
        super().__init__(nombre,dureza,fractura, color, composicion, lustre, gravedad_especifica, sistema_cristalino)
        self.archivo=archivo
        self.temperaturas=[]
        self.volumenes=[]
        try:
            df = pd.read_csv(archivo)
            self.temperaturas = df['Temperatura'].tolist()
            self.volumenes = df['Volumen'].tolist()
        except FileNotFoundError:
            print(f"El archivo CSV '{archivo}' no fue encontrado.")
        except Exception as e:
            print(f"Error al leer el archivo CSV: {str(e)}")
        

    def coeficiente_expansion_termica(self):
        n = len(self.temperaturas)
        alfas=[]
        for i in range (1, n-1):
            dT_i= self.temperaturas[i + 1] - self.temperaturas[i]
            dT_j = self.temperaturas[i] - self.temperaturas[i - 1]
            dV_i = self.volumenes[i + 1] - self.volumenes[i]
            dV_j = self.volumenes[i] - self.volumenes[i - 1]
            alfa_i = (1 / self.volumenes[i]) * (dV_i/ dT_i)
            alfa_j = (1 / self.volumenes[i]) * (dV_j / dT_j)
            alfa = (alfa_i + alfa_j)/2
            alfas.append(alfa)

        error_global = sum(abs(alfas[i] - alfas[i - 1]) for i in range(1, len(alfas))) / (len(alfas) - 1) if len(alfas) > 1 else 0.0

  
        plt.figure(figsize=(12, 5))

     
        plt.subplot(1, 2, 1)
        plt.plot(self.temperaturas, self.volumenes, marker='o', linestyle='-', color='b')
        plt.xlabel('Temperatura (°C)')
        plt.ylabel('Volumen (cm^3)')
        plt.title('Volumen vs. Temperatura')

        plt.subplot(1, 2, 2)
        plt.plot(self.temperaturas[1:-1], alfas, marker='o', linestyle='-', color='r')
        plt.xlabel('Temperatura (°C)')
        plt.ylabel('Coeficiente de Expansión Térmica (α)')
        plt.title('α vs. Temperatura')

        plt.tight_layout()
        plt.show()

        return alfas, error_global


    
        
