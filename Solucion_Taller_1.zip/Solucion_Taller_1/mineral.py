import matplotlib.pyplot as plt


class Mineral:
    def __init__(self, nombre:str,dureza:float,fractura:bool, color:str, composicion:str, lustre:str, gravedad_especifica:float, 
                 sistema_cristalino:str):
        self.nombre= nombre
        self.dureza = dureza
        self.lustre = lustre
        self.fractura= fractura
        self.color = color
        self.composicion = composicion
        self.sistema_cristalino= sistema_cristalino
        self.gravedad_especifica= gravedad_especifica
    
    def es_silicato(self):
        if "si" in self.composicion.lower() and "o" in self.composicion.lower():
            return True
        else:
            return False
        
    def densidad_material(self):
        densidad_agua=1000
        densidad_mineral= densidad_agua*self.gravedad_especifica
        return densidad_mineral
    
    def visualizacion_color(self):
        fig, ax = plt.subplots()
        ax.add_patch(plt.Rectangle((0, 0), 1, 1, color=self.color))
        ax.set_xlim(0, 1)
        ax.set_ylim(0, 1)
        ax.axis('off')  
        return plt.show()
    
    def info_mineral(self):
       print("Su dureza en escala de Mohs es de " + str(self.dureza) + "\n")
       if self.fractura ==True:
           print("El mineral se rompe por fractura\n")
       elif self.fractura == False:
           print("El mineral se rompe por escisión\n")
       else:
           print("No se tiene información acerca de la fractura de este mineral\n")
       print("El sistema de organización de los átomos es: " + str(self.sistema_cristalino) + "\n")



            